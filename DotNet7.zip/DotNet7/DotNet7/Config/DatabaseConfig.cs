﻿namespace DotNet7.Config
{
    public class DatabaseConfig
    {
        public string ConnectionString { get; set; }
    }
}
